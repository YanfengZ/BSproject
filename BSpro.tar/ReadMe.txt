我的服务器部署出现一些问题，7.2日重新配置好后会发送邮件告知您网站地址方便您评审
python版本：3.6
django版本：1.11
mysql5.7数据库：
        
        'USER': 'root',
        'PASSWORD': '123456',
        'HOST': '127.0.0.1',
        'PORT': '3306',
		'NAME': 'mysite',
再启动程序前，需要先在数据库中建立schema 命名为mysite

然后打开manage.py所在目录，并运行：
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 0.0.0.0:8080

打开浏览器，输入127.0.0.1:8080即可访问
如果出现import error，请使用pip install命令安装相关模块